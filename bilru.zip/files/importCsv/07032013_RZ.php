<?php
                $paramsArray = array(
                    "table"=>"bl_goszakaz",
                    "delimiter"=>";",
		    "textDelimiter"=>"\"",
                    "mode"=>1,
                    "perRequest"=>10,
                    "csvKey"=>"",
                    "tableKey"=>"",
                    "columns"=>array(
                        "id"=>"", "title"=>3, "price"=>6, "start_date"=>14, "end_date"=>15, "work_type"=>8, "object"=>"", "object_address"=>"", "customer"=>9, "placement"=>2, "status"=>"", "material"=>"", "duration"=>"", "contact"=>"", "phone"=>"", "email"=>"", "persona"=>"", "docs"=>"", "link"=>1, "object_id"=>"", 
                    ),
                );
            ?>