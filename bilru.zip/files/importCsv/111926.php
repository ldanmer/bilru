<?php
                $paramsArray = array(
                    "table"=>"bl_goszakaz",
                    "delimiter"=>";",
		    "textDelimiter"=>"\"",
                    "mode"=>1,
                    "perRequest"=>10,
                    "csvKey"=>"2",
                    "tableKey"=>"id",
                    "columns"=>array(
                        "id"=>2, "title"=>4, "price"=>5, "start_date"=>8, "end_date"=>9, "work_type"=>"", "object"=>"", "object_address"=>11, "customer"=>3, "placement"=>7, "status"=>"", "material"=>"", "duration"=>"", "contact"=>11, "phone"=>12, "email"=>13, "persona"=>14, "docs"=>"", "link"=>6, "object_id"=>"", 
                    ),
                );
            ?>