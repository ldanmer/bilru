<?php
                $paramsArray = array(
                    "table"=>"bl_zakupki",
                    "delimiter"=>";",
		    "textDelimiter"=>"\"",
                    "mode"=>1,
                    "perRequest"=>50,
                    "csvKey"=>"",
                    "tableKey"=>"",
                    "columns"=>array(
                        "id"=>"", "name"=>2, "organization"=>4, "placement"=>1, "price"=>3, "status"=>5, "start_date"=>6, "stop_date"=>7, 
                    ),
                );
            ?>