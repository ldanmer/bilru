<?php
return array (
  'guest' => 
  array (
    'type' => 2,
    'description' => 'Гость',
    'bizRule' => NULL,
    'data' => NULL,
  ),
);
