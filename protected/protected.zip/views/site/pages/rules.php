<?php
$this->pageTitle='Правила';
$this->breadcrumbs=array(
	'Правила',
);
?>
Правила
