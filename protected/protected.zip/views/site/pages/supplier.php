<?php
$this->pageTitle='Поставщику';
$this->breadcrumbs=array(
	'Поставщику',
);
?>
<h1 class="text-error">Поставщику</h1>
<div class="customer">
<h3 class="text-error">на конкурсной основе:</h3>	
	<ul>
		<li><img src="<?php echo Yii::app()->baseUrl ?>/images/glyphicons_027_search.png" /> найти подрядчика – компанию, бригаду или мастера</li> 
		<li><img src="<?php echo Yii::app()->baseUrl ?>/images/glyphicons_059_cargo.png" /> заказать архитектурный, рабочий или дизайн проект</li>		
		<li><img src="<?php echo Yii::app()->baseUrl ?>/images/glyphicons_019_heart_empty.png" /> просмотреть и оставить отзыв и оценки подрядчиков и поставщиков</li>
		<li><img src="<?php echo Yii::app()->baseUrl ?>/images/glyphicons_202_shopping_cart.png" /> купить строительные и отделочные материалы, инженерное оборудование</li>
		<li><img src="<?php echo Yii::app()->baseUrl ?>/images/glyphicons_069_gift.png" /> принять участие в акциях, получить купон или скидку на товары или услуги</li>
	</ul>
</div>