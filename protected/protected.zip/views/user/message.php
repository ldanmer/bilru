<?php $this->pageTitle=Yii::app()->name?>

<h1>Активация пользователя</h1>

<div class="form">
<?php echo $content; ?>

</div><!-- yiiForm -->